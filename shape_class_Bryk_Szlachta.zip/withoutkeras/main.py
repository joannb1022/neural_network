import window


okno = window.InputWindow(3)
okno.show()
